# Testy do zadania artmetyka.

## Zasady kontrybucji
- Testy dodajemy do oddzielnych plików. Jeśli chcesz stworzyć wiele plików to zrób folder. 
- Jeśli w którymś teście jest błąd zgłoś Issue i/lub zrób forka, na forku popraw i zrób Merge Request.

## Używanie

1. Umieść swoje rozwiązanie w pliku arytmetyka.ml
2. `./testuj.sh`

## Standaryzacja testów:
- **TODO**
- 